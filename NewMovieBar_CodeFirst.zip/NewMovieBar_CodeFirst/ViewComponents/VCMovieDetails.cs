﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models;
using System.Diagnostics;
using System.Threading.Tasks;

namespace NewMovieBar_CodeFirst.ViewComponents
{
    public class VCMovieDetails : ViewComponent
    {
        private readonly NewMovieBarContext _context;

        public VCMovieDetails(NewMovieBarContext context)
        {
            _context = context;
        }

        // 2.4.4 撰寫 InvokeAsync() 方法取得回覆留言資料
        public async Task<IViewComponentResult> InvokeAsync(string movieid)
        {
            var movieDetail = await _context.Movie.Where(r => r.MovieID == movieid).ToListAsync();
            return View( movieDetail);
        }
    }
}
