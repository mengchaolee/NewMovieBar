﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models;

namespace NewMovieBar_CodeFirst.ViewComponents
{

    //2.4.3 VCReBooks class繼承ViewComponent(注意using Microsoft.AspNetCore.Mvc;)
    public class VCMovieGrades : ViewComponent
    {
        private readonly NewMovieBarContext _context;

        public VCMovieGrades(NewMovieBarContext context)
        {
            _context = context;
        }

        //2.4.4 撰寫InvokeAsync()方法取得回覆留言資料
        public async Task<IViewComponentResult> InvokeAsync(string movieid)
        {
            var Grade = await _context.MovieGrade.Where(r => r.MovieID == movieid).ToListAsync();
            return View(Grade);
        }





    }
}
