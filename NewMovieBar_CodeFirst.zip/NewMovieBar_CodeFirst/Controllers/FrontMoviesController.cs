﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models;

namespace MovieBar_CodeFirst.Controllers
{
    public class FrontMoviesController : Controller
    {
        private readonly NewMovieBarContext _context;

        public FrontMoviesController(NewMovieBarContext context)
        {
            _context = context;
        }

        // GET: FrontMovies
        public async Task<IActionResult> Index()
        {
            return View(await _context.Movie.ToListAsync());
        }

        


        // GET: FrontMovies/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var movie = await _context.Movie
                .FirstOrDefaultAsync(m => m.MovieID == id);
            if (movie == null)
            {
                return NotFound();
            }

            return View(movie);
        }

        
        private bool MovieExists(string id)
        {
            return _context.Movie.Any(e => e.MovieID == id);
        }
    }
}
