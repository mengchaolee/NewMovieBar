﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models;

namespace NewMovieBar_CodeFirst.Controllers
{
    public class MovieCollectsController : Controller
    {
        private readonly NewMovieBarContext _context;

        public MovieCollectsController(NewMovieBarContext context)
        {
            _context = context;
        }

        // GET: MovieCollects
        public async Task<IActionResult> Index()
        {
            var newMovieBarContext = _context.MovieCollect.Include(m => m.Member).Include(m => m.Movie);
            return View(await newMovieBarContext.ToListAsync());
        }



        //傳照片
        public FileContentResult GetImage(string MovieID)
        {

            var Movie = _context.Movie.Find(MovieID);

            if (Movie != null)
            {
                return File(Movie.PosterImg, Movie.ImageType);
            }

            return null;
        }

        // GET: MovieCollects/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var movieCollect = await _context.MovieCollect
                .Include(m => m.Member)
                .Include(m => m.Movie)
                .FirstOrDefaultAsync(m => m.MCId == id);
            if (movieCollect == null)
            {
                return NotFound();
            }

            return View(movieCollect);
        }

        // GET: MovieCollects/Create
        public IActionResult Create()
        {
            ViewData["Account"] = new SelectList(_context.Member, "Account", "Account");
            ViewData["MovieID"] = new SelectList(_context.Movie, "MovieID", "MovieID");
            return View();
        }

        // POST: MovieCollects/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MCId,MovieID,Account,CollectTime")] MovieCollect movieCollect)
        {
            movieCollect.CollectTime = DateTime.Now;
            ModelState.Remove("Movie");
            ModelState.Remove("Member");
            if (ModelState.IsValid)
            {
                _context.Add(movieCollect);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["Account"] = new SelectList(_context.Member, "Account", "Account", movieCollect.Account);
            ViewData["MovieID"] = new SelectList(_context.Movie, "MovieID", "MovieID", movieCollect.MovieID);
            return View(movieCollect);
        }

        // GET: MovieCollects/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var movieCollect = await _context.MovieCollect.FindAsync(id);
            if (movieCollect == null)
            {
                return NotFound();
            }
            ViewData["Account"] = new SelectList(_context.Member, "Account", "Account", movieCollect.Account);
            ViewData["MovieID"] = new SelectList(_context.Movie, "MovieID", "MovieID", movieCollect.MovieID);
            return View(movieCollect);
        }

        // POST: MovieCollects/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, [Bind("MCId,MovieID,Account,CollectTime")] MovieCollect movieCollect)
        {
            if (id != movieCollect.MCId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(movieCollect);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MovieCollectExists(movieCollect.MCId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["Account"] = new SelectList(_context.Member, "Account", "Account", movieCollect.Account);
            ViewData["MovieID"] = new SelectList(_context.Movie, "MovieID", "MovieID", movieCollect.MovieID);
            return View(movieCollect);
        }

        // GET: MovieCollects/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var movieCollect = await _context.MovieCollect
                .Include(m => m.Member)
                .Include(m => m.Movie)
                .FirstOrDefaultAsync(m => m.MCId == id);
            if (movieCollect == null)
            {
                return NotFound();
            }

            return View(movieCollect);
        }

        // POST: MovieCollects/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            var movieCollect = await _context.MovieCollect.FindAsync(id);
            if (movieCollect != null)
            {
                _context.MovieCollect.Remove(movieCollect);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MovieCollectExists(long id)
        {
            return _context.MovieCollect.Any(e => e.MCId == id);
        }

        [HttpPost]
        public JsonResult AddToCollection(string movieId, string memberAccount)
        {
            try
            {
                // 檢查資料庫是否已經存在相同的資料
                bool isDuplicate = _context.MovieCollect.Any(mc => mc.MovieID == movieId && mc.Account == memberAccount);

                if (isDuplicate)
                {
                    return Json(new { success = false, errors = "此電影已收藏" });
                }

                // 如果沒有重複，則加入蒐藏
                var movieCollect = new MovieCollect
                {
                    MovieID = movieId,
                    Account = memberAccount,
                    CollectTime = DateTime.Now
                };

                _context.MovieCollect.Add(movieCollect);
                _context.SaveChanges();

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errors = ex.Message });
            }
        }



    }
}