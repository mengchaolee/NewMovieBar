﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models;

namespace MovieBar_CodeFirst.Controllers
{
    public class FrontCinemasController : Controller
    {
        private readonly NewMovieBarContext _context;

        public FrontCinemasController(NewMovieBarContext context)
        {
            _context = context;
        }

        // GET: FrontCinemas
        public async Task<IActionResult> Index()
        {
            return View(await _context.Cinema.ToListAsync());
        }

        // GET: FrontCinemas/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cinema = await _context.Cinema
                .FirstOrDefaultAsync(m => m.CinemaID == id);
            if (cinema == null)
            {
                return NotFound();
            }

            return View(cinema);
        }

        

        private bool CinemaExists(string id)
        {
            return _context.Cinema.Any(e => e.CinemaID == id);
        }
    }
}
