﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages;
using NewMovieBar_CodeFirst.Models;
using Newtonsoft.Json;
using System.Linq;
using System.Threading.Tasks;

namespace NewMovieBar_CodeFirst.Controllers
{
    public class MemberLoginController : Controller
    {
        private readonly NewMovieBarContext _context;

        public MemberLoginController(NewMovieBarContext context)
        {
            _context = context;
        }

     
    }
}