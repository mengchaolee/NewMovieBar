﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models;

namespace NewMovieBar_CodeFirst.Controllers
{
    public class FrontAddMembersController : Controller
    {
        private readonly NewMovieBarContext _context;

        public FrontAddMembersController(NewMovieBarContext context)
        {
            _context = context;
        }

        // GET: FrontAddMembers
        public async Task<IActionResult> Index()
        {
            return View(await _context.Member.ToListAsync());
        }

       

        // GET: FrontAddMembers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: FrontAddMembers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Account,Password,Name,Birth")] Member member)
        {
            if (ModelState.IsValid)
            {
                _context.Add(member);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(Index);
        }

       
    }
}
