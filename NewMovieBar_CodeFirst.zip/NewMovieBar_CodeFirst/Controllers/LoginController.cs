﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models;
using Newtonsoft.Json;

namespace NewMovieBar_CodeFirst.Controllers
{
    public class LoginController : Controller
    {

        private readonly NewMovieBarContext _context;

        public LoginController(NewMovieBarContext context)
        {
            _context = context;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(Login login)
        {
            if (login == null)
            {
                return View();
            }

            var result=_context.Login.Where(x=>x.ManagerAccount==login.ManagerAccount && x.ManagerPassword==login.ManagerPassword).FirstOrDefaultAsync();
            if(result == null) 
            {
                ViewData["ErrorMsg"] = "帳號或密碼錯誤!!";
                return View(login);
            }
            //輸入的帳號或密碼正確的處理
            //進行登入成功的狀態保留,保留在sessio物件中

            HttpContext.Session.SetString("Manager", JsonConvert.SerializeObject(login));

            return RedirectToAction("Index", "Movies");
        }

        //4.4.1 在Login Controller加入Logout Action
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("Manager");

            return RedirectToAction("Login", "Login");
        }
            
        
    }
}
