﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models;

namespace NewMovieBar_CodeFirst.Controllers
{
    public class MemberShowtimesController : Controller
    {
        private readonly NewMovieBarContext _context;

        public MemberShowtimesController(NewMovieBarContext context)
        {
            _context = context;
        }

        // GET: MemberShowtimes
        public async Task<IActionResult> Index()
        {
            var newMovieBarContext = _context.Showtime.Include(s => s.Cinema).Include(s => s.Movie);
            return View(await newMovieBarContext.ToListAsync());
        }

        // GET: MemberShowtimes/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var showtime = await _context.Showtime
                .Include(s => s.Cinema)
                .Include(s => s.Movie)
                .FirstOrDefaultAsync(m => m.MSId == id);
            if (showtime == null)
            {
                return NotFound();
            }

            return View(showtime);
        }

        // GET: MemberShowtimes/Create
        public IActionResult Create()
        {
            ViewData["CinemaID"] = new SelectList(_context.Cinema, "CinemaID", "CinemaID");
            ViewData["MovieID"] = new SelectList(_context.Movie, "MovieID", "MovieID");
            return View();
        }

        // POST: MemberShowtimes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MSId,MovieID,CinemaID,Date,Time")] Showtime showtime)
        {
            if (ModelState.IsValid)
            {
                _context.Add(showtime);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CinemaID"] = new SelectList(_context.Cinema, "CinemaID", "CinemaID", showtime.CinemaID);
            ViewData["MovieID"] = new SelectList(_context.Movie, "MovieID", "MovieID", showtime.MovieID);
            return View(showtime);
        }

        // GET: MemberShowtimes/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var showtime = await _context.Showtime.FindAsync(id);
            if (showtime == null)
            {
                return NotFound();
            }
            ViewData["CinemaID"] = new SelectList(_context.Cinema, "CinemaID", "CinemaID", showtime.CinemaID);
            ViewData["MovieID"] = new SelectList(_context.Movie, "MovieID", "MovieID", showtime.MovieID);
            return View(showtime);
        }

        // POST: MemberShowtimes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, [Bind("MSId,MovieID,CinemaID,Date,Time")] Showtime showtime)
        {
            if (id != showtime.MSId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(showtime);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ShowtimeExists(showtime.MSId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CinemaID"] = new SelectList(_context.Cinema, "CinemaID", "CinemaID", showtime.CinemaID);
            ViewData["MovieID"] = new SelectList(_context.Movie, "MovieID", "MovieID", showtime.MovieID);
            return View(showtime);
        }

        // GET: MemberShowtimes/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var showtime = await _context.Showtime
                .Include(s => s.Cinema)
                .Include(s => s.Movie)
                .FirstOrDefaultAsync(m => m.MSId == id);
            if (showtime == null)
            {
                return NotFound();
            }

            return View(showtime);
        }

        // POST: MemberShowtimes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            var showtime = await _context.Showtime.FindAsync(id);
            if (showtime != null)
            {
                _context.Showtime.Remove(showtime);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ShowtimeExists(long id)
        {
            return _context.Showtime.Any(e => e.MSId == id);
        }
    }
}
