﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewMovieBar_CodeFirst.Models; // 导入你的 DbContext 类的命名空间

namespace NewMovieBar_CodeFirst.Controllers
{
    public class MemberHomeController : Controller
    {
        private readonly NewMovieBarContext _context; // 将 YourDbContext 替换为实际的 DbContext 类名

        public MemberHomeController(NewMovieBarContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var movies = _context.Movie.Where(b => b.PosterImg != null).OrderByDescending(b => b.ReleaseDate).Take(10).ToList();
            return View(movies);
        }
    }
}
