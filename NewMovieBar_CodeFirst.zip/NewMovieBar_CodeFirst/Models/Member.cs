﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace NewMovieBar_CodeFirst.Models
{
    public class Member
    {

        [Key]
        [DisplayName("帳號")]
        [Required(ErrorMessage = "請填寫帳號")]
        [StringLength(8, ErrorMessage = "帳號最多8碼")]
        public string Account { get; set; } = null!;

        [DisplayName("密碼")]
        [Required(ErrorMessage = "請填寫密碼")]
        [DataType(DataType.Password)]
        [StringLength(8)]
        [MinLength(8, ErrorMessage = "密碼最少8碼")]
        [MaxLength(8, ErrorMessage = "密碼最少8碼")]
        public string Password { get; set; } = null!;

        [Display(Name = "姓名")]
        [Required(ErrorMessage = "必填")]
        [StringLength(30, ErrorMessage = "最多30個字")]
        public string Name { get; set; } = null!;

        [Display(Name = "生日")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [Required(ErrorMessage = "必填")]
        public DateTime Birth { get; set; } 

       
        public virtual List<MovieCollect>? MovieCollects { get; set; }

        public virtual List<MovieGrade>? MovieGrades { get; set; }
        public virtual List<MovieMessage>? MovieMessages { get; set; }

    }
}
