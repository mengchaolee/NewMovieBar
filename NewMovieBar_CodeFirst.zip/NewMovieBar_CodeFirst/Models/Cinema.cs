﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace NewMovieBar_CodeFirst.Models
{
    public class Cinema
    {

        [Key]
        [Display(Name = "電影院ID")]
        [Required(ErrorMessage = "必填")]
        [StringLength(6, ErrorMessage = "最多6個字")]
        [RegularExpression("C[0-9]{5}", ErrorMessage = "格式錯誤(ex:Cxxxxx)")]
        public string CinemaID { get; set; } = null!;


        [Display(Name = "電影院名稱")]
        [Required(ErrorMessage = "必填")]
        [StringLength(30, ErrorMessage = "最多30個字")]
        public string CinemaName { get; set; } = null!;

        [Display(Name = "縣市")]
        [Required(ErrorMessage = "必填")]
        [StringLength(30, ErrorMessage = "最多30個字")]
        public string City { get; set; } = null!;

        [Display(Name = "道路")]
        [Required(ErrorMessage = "必填")]
        [StringLength(30, ErrorMessage = "最多30個字")]
        public string Road { get; set; } = null!;

        [Display(Name = "電話")]
        [Required(ErrorMessage = "必填")]
        [StringLength(20, ErrorMessage = "最多20個字")]
        public string Tel { get; set; } = null!;


        [Display(Name = "網址")]
        [Required(ErrorMessage = "必填")]
        [StringLength(1000)]
        public string Web { get; set; } = null!;


     
        public virtual List<Showtime>? Showtimes { get; set; }
       


    }
}
