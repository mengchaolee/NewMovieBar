﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace NewMovieBar_CodeFirst.Models
{
    public class Movie
    {
        [Key]
        [Display(Name = "電影ID")]
        [Required(ErrorMessage = "必填")]
        [StringLength(6, ErrorMessage = "最多6個字")]
[RegularExpression("M[0-9]{5}", ErrorMessage = "格式錯誤(ex:Mxxxxx)")]
        public string MovieID { get; set; } = null!;



        [Display(Name = "電影名稱")]
        [Required(ErrorMessage = "必填")]
        [StringLength(30, ErrorMessage = "最多30個字")]
        public string MovieTitle { get; set; } = null!;


        [Display(Name = "導演")]
        [Required(ErrorMessage = "必填")]
        [StringLength(30, ErrorMessage = "最多30個字")]
        public string Director { get; set; } = null!;



        [Display(Name = "上映時間")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [Required(ErrorMessage = "必填")]
        public DateTime ReleaseDate { get; set; }


        [Display(Name = "海報圖片")]
        public byte[]? PosterImg { get; set; }


        [StringLength(10)]
        [HiddenInput]
        public string? ImageType { get; set; }


        [Display(Name = "演員")]
        [Required(ErrorMessage = "必填")]
        [StringLength(40, ErrorMessage = "最多40個字")]
        public string? ActorsName { get; set; } 


        [Display(Name = "劇情簡介")]
        [Required(ErrorMessage = "必填")]
        [DataType(DataType.MultilineText)]
        public string Summary { get; set; } = null!;

        [Display(Name = "分級")]
        [StringLength(10)]
        [Required(ErrorMessage = "必填")]
        public string Rating { get; set; } = null!;

        [Display(Name = "片長")]
        [StringLength(10)]
        [Required(ErrorMessage = "必填")]
        public string MovieDuration { get; set; } = null!;

        [Display(Name = "分類")]
        [Required(ErrorMessage = "必填")]
        [StringLength(10, ErrorMessage = "最多10個字")]
        public string Genres { get; set; } = null!;


        public virtual List<Showtime>? Showtimes { get; set; }
        public virtual List<MovieCollect>? MovieCollects { get; set; }

        public virtual List<MovieGrade>? MovieGrades { get; set; }
        public virtual List<MovieMessage>? MovieMessages { get; set; }

    }
}
