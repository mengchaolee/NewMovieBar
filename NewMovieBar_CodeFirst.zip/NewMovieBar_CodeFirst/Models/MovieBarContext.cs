﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace NewMovieBar_CodeFirst.Models
{
    public class NewMovieBarContext : DbContext  //(1)須繼承DbContext類別
    {

        //(2)撰寫建構子
        public NewMovieBarContext(DbContextOptions<NewMovieBarContext> options) : base(options)
        {

        }

        public virtual DbSet<Movie> Movie { get; set; }
        public virtual DbSet<Member> Member { get; set; }
        public virtual DbSet<Cinema> Cinema { get; set; }
        public virtual DbSet<Showtime> Showtime { get; set; }
        public virtual DbSet<MovieCollect> MovieCollect { get; set; }
        public virtual DbSet<MovieGrade> MovieGrade { get; set; }
        public virtual DbSet<MovieMessage> MovieMessage { get; set; }

        public virtual DbSet<Login> Login { get; set; }


    }
}
