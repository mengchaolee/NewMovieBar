﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NewMovieBar_CodeFirst.Models
{
    public class MovieMessage
    {

        [Key]
        public long MMId { get; set; }

     
        [ForeignKey("Movie")]
        [Display(Name = "電影ID")]
        [Required(ErrorMessage = "必填")]
        [StringLength(6, ErrorMessage = "最多6個字")]
        [RegularExpression("M[0-9]{5}", ErrorMessage = "格式錯誤(ex:Mxxxxx)")]
        public string MovieID { get; set; } = null!;
        public virtual Movie Movie { get; set; } = null!;


        [ForeignKey("Member")]
        [DisplayName("帳號")]
        [Required(ErrorMessage = "請填寫帳號")]
        [StringLength(8, ErrorMessage = "帳號最多8碼")]

        public string Account { get; set; } = null!;
        public virtual Member Member { get; set; } = null!;


        [Display(Name = "留言內容")]
        [Required(ErrorMessage = "必填")]
        [StringLength(300, ErrorMessage = "最多300個字")]
        public string Message { get; set; } = null!;

        [Display(Name = "留言時間")]
        public DateTime MTime { get; set; }



    }
}
