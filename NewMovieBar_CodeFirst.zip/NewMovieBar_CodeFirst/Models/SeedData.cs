﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace NewMovieBar_CodeFirst.Models
{
    public class SeedData
    {
        //(1)撰寫靜態方法 Initialize(IServiceProvider serviceProvider)
        public static void Initialize(IServiceProvider serviceProvider)
        {
            //(2)撰寫Book及ReBook資料表內的初始資料程式

            using (var context = new NewMovieBarContext(serviceProvider.GetRequiredService<DbContextOptions<NewMovieBarContext>>()))
            {
                if (!context.Movie.Any())
                {
                    context.Movie.AddRange(
                         new Movie
                         {
                             MovieID = "M00001",
                             MovieTitle = "鬼聲泣",
                             Director = "納得克庫吉米亞",
                             ReleaseDate = new DateTime(2024, 1, 19),
                             PosterImg = getFileBytes("SeedSourcePhoto/M00001.jpg"),
                             ImageType = "image/jpeg",
                             Summary = "《陰巢》塔偉華温泰執導，《騙騙愛上你》納得克庫吉米亞、《愛情遊戲詭計》潔莉爾查卡本、《不解之緣》拉塔娃蒂婉通主演，全球首部IMAX泰國鬼片，超大銀幕沉浸式體驗，恐懼直奔眼球。",
                             Rating = "輔導級",
                             MovieDuration = "2時01分",
                             ActorsName = "納得克·釘宮、阿麗莎拉·翁差麗",
                             Genres = "恐怖"
                         },
                              new Movie
                              {
                                  MovieID = "M00002",
                                  MovieTitle = "蜂刑者",
                                  Director = "大衛艾亞",
                                  ReleaseDate = new DateTime(2024, 1, 12),
                                  PosterImg = getFileBytes("SeedSourcePhoto/M00002.jpg"),
                                  ImageType = "image/jpeg",
                                  Summary = "在摯友因遭詐騙而自殺身亡後，一名過去成謎的男子克雷（傑森史塔森 飾）滿腔怒火地對詐騙集團展開激烈的復仇。然而，當人們發現克雷曾是祕密組織「蜂刑者」的成員時，復仇不再只是他的私人恩怨，更是一場動搖國本的殺戮行動……。",
                                  Rating = "輔導級",
                                  MovieDuration = "1時45分",
                                  ActorsName = "傑森·史塔森、安柏·席安娜",
                                  Genres = "動作"
                              },
                               new Movie
                               {
                                   MovieID = "M00003",
                                   MovieTitle = "可憐的東西",
                                   Director = "尤格藍西莫",
                                   ReleaseDate = new DateTime(2024, 2, 8),
                                   PosterImg = getFileBytes("SeedSourcePhoto/M00003.jpg"),
                                   ImageType = "image/jpeg",
                                   Summary = "導演尤格藍西莫和艾瑪史東繼《真寵》後再度合作，艾瑪史東扮演在科學家手中復活的女子貝拉，她不僅渴望學習，還和律師私奔，展開跨越世界各大洲的冒險。擺脫該時代的偏見，為她追求平等與解放的信念前進。",
                                   Rating = "輔導級",
                                   MovieDuration = "2時21分",
                                   ActorsName = "艾瑪史東、瑪格麗特庫利、威廉達佛",
                                   Genres = "科幻"
                               },
                               new Movie
                               {
                                   MovieID = "M00004",
                                   MovieTitle = "外星+人2：回到未來",
                                   Director = "崔東勛",
                                   ReleaseDate = new DateTime(2024, 2, 7),
                                   PosterImg = getFileBytes("SeedSourcePhoto/M00004.jpg"),
                                   ImageType = "image/jpeg",
                                   Summary = "為了阻止被關在人類體內的外星人囚犯逃獄，被困在過去的以安（金泰梨 飾）歷經波折後，終於獲得能打開時間之門的「神劍」，並找到森德（金宇彬 飾），打算回到自己所離開的未來。",
                                   Rating = "輔導級",
                                   MovieDuration = "2時02分",
                                   ActorsName = "金泰梨、金宇彬、李荷妮",
                                   Genres = "科幻"
                               },
                              new Movie
                              {
                                  MovieID = "M00005",
                                  MovieTitle = "飛鴨向前衝",
                                  Director = "班傑明雷納",
                                  ReleaseDate = new DateTime(2024, 2, 8),
                                  PosterImg = getFileBytes("SeedSourcePhoto/M00005.jpg"),
                                  ImageType = "image/jpeg",
                                  Summary = "《小小兵》、《神偷奶爸》的照明娛樂將推出喜劇動畫片《飛鴨向前衝》，藉由一個搞笑的鴨子家庭的冒險旅程講述我們應該克服自己內心的恐懼，打開心房接納這個世界以及各種可能性。",
                                  Rating = "普遍級",
                                  MovieDuration = "1時31分",
                                  ActorsName = "庫梅爾·南賈尼、伊莉莎白·班克絲、奧卡菲娜",
                                  Genres = "喜劇"
                              },
                              new Movie
                              {
                                  MovieID = "M00006",
                                  MovieTitle = "蜘蛛夫人",
                                  Director = "S·J·克拉克森",
                                  ReleaseDate = new DateTime(2024, 2, 14),
                                  PosterImg = getFileBytes("SeedSourcePhoto/M00006.jpg"),
                                  ImageType = "image/jpeg",
                                  Summary = "蜘蛛人番外篇，劇情聚焦在一個名為韋伯夫人的千里眼突變體上。",
                                  Rating = "保護級",
                                  MovieDuration = "2時01分",
                                  ActorsName = "納得克·釘宮、阿麗莎拉·翁差麗",
                                  Genres = "動作"
                              },
                              new Movie
                              {
                                  MovieID = "M00007",
                                  MovieTitle = "火上鍋",
                                  Director = "陳英雄",
                                  ReleaseDate = new DateTime(2024, 2, 23),
                                  PosterImg = getFileBytes("SeedSourcePhoto/M00007.jpg"),
                                  ImageType = "image/jpeg",
                                  Summary = "第76屆坎城影展最佳導演獎，《三輪車伕》越裔法籍導演陳英雄執導，茱麗葉畢諾許與班諾馬吉梅主演，本片由摘下14 顆米其林星的法國當代最頂尖廚師皮耶加尼葉（Pierre Gagnaire），擔任烹飪指導。",
                                  Rating = "保護級",
                                  MovieDuration = "2時15分",
                                  ActorsName = "茱麗葉畢諾許、班諾馬吉梅",
                                  Genres = "愛情"
                              },
                              new Movie
                              {
                                  MovieID = "M00008",
                                  MovieTitle = "還錢 ",
                                  Director = "王鼎霖",
                                  ReleaseDate = new DateTime(2024, 2, 8),
                                  PosterImg = getFileBytes("SeedSourcePhoto/M00008.jpg"),
                                  ImageType = "image/jpeg",
                                  Summary = "葉如芬監製，《第九分局》導演王鼎霖編劇、執導，陳柏霖、蔡思韵、李銘忠、林哲熹、蔡凡熙等人主演。",
                                  Rating = "保護級",
                                  MovieDuration = "1時40分",
                                  ActorsName = "陳柏霖、蔡思韵",
                                  Genres = "喜劇"
                              },
                              new Movie
                              {
                                  MovieID = "M00009",
                                  MovieTitle = "愛愛愛上你",
                                  Director = "威爾古勒",
                                  ReleaseDate = new DateTime(2024, 2, 2),
                                  PosterImg = getFileBytes("SeedSourcePhoto/M00009.jpg"),
                                  ImageType = "image/jpeg",
                                  Summary = "《破處女王》、《好友萬萬睡》威爾古勒執導，《決戰38度線》格蘭鮑威爾、《從前，有個好萊塢》席德妮史威尼主演，愛愛而已不代表愛你？大肌肌男神 vs 新生代美乳女神 看誰先暈！",
                                  Rating = "輔導級",
                                  MovieDuration = "1時43分",
                                  ActorsName = "格蘭鮑威爾、亞利珊卓希普、達倫巴奈特",
                                  Genres = "愛情"
                              },
                              new Movie
                              {
                                  MovieID = "M00010",
                                  MovieTitle = "劇場版 轉生成女性向遊戲只有毀滅 END 的壞人大小姐",
                                  Director = "井上圭介",
                                  ReleaseDate = new DateTime(2024, 1, 25),
                                  PosterImg = getFileBytes("SeedSourcePhoto/M00010.jpg"),
                                  ImageType = "image/jpeg",
                                  Summary = "轉生至前世玩過的女性向遊戲「 FORTUNE LOVE 」世界裡成為壞人大小姐的卡塔莉娜，成功迴避多次的毀滅結局，春天從魔法學園畢業之後便進入魔法省工作，過著平穩的生活。 直到有一天，來自遙遠異國的一群商人突然到來，光彩耀眼的表演和舞者吸引了卡塔莉娜的目光，也因此與謎樣般的少年相識。似乎曾在哪裡見過面的少年，這個相遇將為卡塔莉娜帶來意想不到的大事件！？",
                                  Rating = "保護級",
                                  MovieDuration = "1時33分",
                                  ActorsName = "無",
                                  Genres = "愛情"
                              }
                        );

                    context.SaveChanges();

                    context.Cinema.AddRange(
                                new Cinema
                                {
                                    CinemaID = "C00001",
                                    CinemaName = "高雄夢時代秀泰影城",
                                    City = "高雄市",
                                    Road = "前鎮區中華五路789號8F",
                                    Tel = "(07)812-2998",
                                    Web = "https://www.showtimes.com.tw/"

                                });
                    context.SaveChanges();

                    context.Member.AddRange(
                               new Member
                               {
                                   Account = "12345678",
                                   Password = "12345678",
                                   Name = "李鴨鴨",
                                   Birth = new DateTime(1992, 8, 21),


                               });

                    context.SaveChanges();


                    context.Showtime.AddRange(
                         new Showtime
                         {
                             CinemaID = "C00001",
                             MovieID = "M00001",
                             Date = new DateTime(2024, 3, 1),
                             Time = new DateTime(2024, 3, 1, 11, 40, 0),


                         });

                    context.SaveChanges();


                    context.MovieCollect.AddRange(
                        new MovieCollect
                        {
                            MovieID = "M00001",
                            Account = "12345678",
                            CollectTime = DateTime.Now,

                        });

                    context.SaveChanges();



                    context.MovieGrade.AddRange(
                       new MovieGrade
                       {
                           MovieID = "M00001",
                           Account = "12345678",
                           Grade = 80,

                       });

                    context.SaveChanges();



                    context.MovieMessage.AddRange(
                      new MovieMessage
                      {
                          MovieID = "M00001",
                          Account = "12345678",
                          Message = "好看",
                          MTime = DateTime.Now,

                      });

                    context.SaveChanges();


                }
            }


            //(3)撰寫getFileBytes，功能為將照片轉成二進位資料
            byte[] getFileBytes(string path)
            {
                FileStream fileOnDisk = new FileStream(path, FileMode.Open);

                byte[] fileBytes;

                using (BinaryReader br = new BinaryReader(fileOnDisk))
                {
                    fileBytes = br.ReadBytes((int)fileOnDisk.Length);
                }

                return fileBytes;

            }
        }
    }
}