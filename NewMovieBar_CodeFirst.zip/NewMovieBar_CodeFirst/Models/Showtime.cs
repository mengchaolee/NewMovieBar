﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NewMovieBar_CodeFirst.Models
{
    public class Showtime
    {

        [Key]
        public long MSId { get; set; }


  
        [ForeignKey("Movie")]
        [Display(Name = "電影ID")]
        [Required(ErrorMessage = "必填")]
        [StringLength(6, ErrorMessage = "最多6個字")]
        [RegularExpression("M[0-9]{5}", ErrorMessage = "格式錯誤(ex:Mxxxxx)")]
        public string MovieID { get; set; } = null!;
        public virtual Movie Movie { get; set; } = null!;


        [ForeignKey("Cinema")]
        [Display(Name = "電影院ID")]
        [Required(ErrorMessage = "必填")]
        [StringLength(6, ErrorMessage = "最多6個字")]
        [RegularExpression("C[0-9]{5}", ErrorMessage = "格式錯誤(ex:Cxxxxx)")]
        public string CinemaID { get; set; } = null!;
        public virtual Cinema Cinema { get; set; } = null!;

        [Display(Name = "日期")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}")]
        [Required(ErrorMessage = "必填")]
        public DateTime Date { get; set; } 

        [Display(Name = "時間")]
        [DisplayFormat(DataFormatString = "{0:HH:mm}")]
        [Required(ErrorMessage = "必填")]
        public DateTime Time { get; set; } 



    }
}
