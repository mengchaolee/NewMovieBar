﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NewMovieBar_CodeFirst.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cinema",
                columns: table => new
                {
                    CinemaID = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    CinemaName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    City = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Road = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Tel = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Web = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cinema", x => x.CinemaID);
                });

            migrationBuilder.CreateTable(
                name: "Member",
                columns: table => new
                {
                    Account = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Birth = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Member", x => x.Account);
                });

            migrationBuilder.CreateTable(
                name: "Movie",
                columns: table => new
                {
                    MovieID = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    MovieTitle = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Director = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    ReleaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PosterImg = table.Column<byte[]>(type: "varbinary(max)", nullable: true),
                    ImageType = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    ActorsName = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Summary = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Rating = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    MovieDuration = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Genres = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Movie", x => x.MovieID);
                });

            migrationBuilder.CreateTable(
                name: "MovieCollect",
                columns: table => new
                {
                    MCId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MovieID = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    Account = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: false),
                    CollectTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MovieCollect", x => x.MCId);
                    table.ForeignKey(
                        name: "FK_MovieCollect_Member_Account",
                        column: x => x.Account,
                        principalTable: "Member",
                        principalColumn: "Account",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MovieCollect_Movie_MovieID",
                        column: x => x.MovieID,
                        principalTable: "Movie",
                        principalColumn: "MovieID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MovieGrade",
                columns: table => new
                {
                    MMId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MovieID = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    Account = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: false),
                    Grade = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MovieGrade", x => x.MMId);
                    table.ForeignKey(
                        name: "FK_MovieGrade_Member_Account",
                        column: x => x.Account,
                        principalTable: "Member",
                        principalColumn: "Account",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MovieGrade_Movie_MovieID",
                        column: x => x.MovieID,
                        principalTable: "Movie",
                        principalColumn: "MovieID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MovieMessage",
                columns: table => new
                {
                    MMId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MovieID = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    Account = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: false),
                    Message = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    MTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MovieMessage", x => x.MMId);
                    table.ForeignKey(
                        name: "FK_MovieMessage_Member_Account",
                        column: x => x.Account,
                        principalTable: "Member",
                        principalColumn: "Account",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MovieMessage_Movie_MovieID",
                        column: x => x.MovieID,
                        principalTable: "Movie",
                        principalColumn: "MovieID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Showtime",
                columns: table => new
                {
                    MSId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MovieID = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    CinemaID = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Time = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Showtime", x => x.MSId);
                    table.ForeignKey(
                        name: "FK_Showtime_Cinema_CinemaID",
                        column: x => x.CinemaID,
                        principalTable: "Cinema",
                        principalColumn: "CinemaID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Showtime_Movie_MovieID",
                        column: x => x.MovieID,
                        principalTable: "Movie",
                        principalColumn: "MovieID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MovieCollect_Account",
                table: "MovieCollect",
                column: "Account");

            migrationBuilder.CreateIndex(
                name: "IX_MovieCollect_MovieID",
                table: "MovieCollect",
                column: "MovieID");

            migrationBuilder.CreateIndex(
                name: "IX_MovieGrade_Account",
                table: "MovieGrade",
                column: "Account");

            migrationBuilder.CreateIndex(
                name: "IX_MovieGrade_MovieID",
                table: "MovieGrade",
                column: "MovieID");

            migrationBuilder.CreateIndex(
                name: "IX_MovieMessage_Account",
                table: "MovieMessage",
                column: "Account");

            migrationBuilder.CreateIndex(
                name: "IX_MovieMessage_MovieID",
                table: "MovieMessage",
                column: "MovieID");

            migrationBuilder.CreateIndex(
                name: "IX_Showtime_CinemaID",
                table: "Showtime",
                column: "CinemaID");

            migrationBuilder.CreateIndex(
                name: "IX_Showtime_MovieID",
                table: "Showtime",
                column: "MovieID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MovieCollect");

            migrationBuilder.DropTable(
                name: "MovieGrade");

            migrationBuilder.DropTable(
                name: "MovieMessage");

            migrationBuilder.DropTable(
                name: "Showtime");

            migrationBuilder.DropTable(
                name: "Member");

            migrationBuilder.DropTable(
                name: "Cinema");

            migrationBuilder.DropTable(
                name: "Movie");
        }
    }
}
